package com.dcai.video;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.OpenableColumns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE = 101;
    private static final int PICK_VIDEO = 102;
    private static final String PREFS = "dc_ai_video_prefs";
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ArrayList<String> demoProjects = new ArrayList<>();
    private EditText promptInput;
    private Spinner ratioSpinner, styleSpinner, durationSpinner;
    private TextView imageStatus, resultText, progressLabel, galleryText, modeLabel, previewStatus;
    private ProgressBar progressBar;
    private Button generateButton, textModeButton, imageModeButton;
    private VideoView videoPreview;
    private Uri selectedImage;
    private Uri selectedVideo;
    private boolean imageToVideoMode = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        promptInput = findViewById(R.id.promptInput);
        ratioSpinner = findViewById(R.id.ratioSpinner);
        styleSpinner = findViewById(R.id.styleSpinner);
        durationSpinner = findViewById(R.id.durationSpinner);
        imageStatus = findViewById(R.id.imageStatus);
        resultText = findViewById(R.id.resultText);
        progressLabel = findViewById(R.id.progressLabel);
        galleryText = findViewById(R.id.galleryText);
        progressBar = findViewById(R.id.progressBar);
        generateButton = findViewById(R.id.generateButton);
        textModeButton = findViewById(R.id.textModeButton);
        imageModeButton = findViewById(R.id.imageModeButton);
        modeLabel = findViewById(R.id.modeLabel);
        previewStatus = findViewById(R.id.previewStatus);
        videoPreview = findViewById(R.id.videoPreview);

        setupSpinner(ratioSpinner, new String[]{"9:16  •  Shorts / Reels", "16:9  •  YouTube", "1:1  •  Square"});
        setupSpinner(styleSpinner, new String[]{"3D", "Realistic", "Anime", "Cartoon"});
        setupSpinner(durationSpinner, new String[]{"5 seconds", "10 seconds", "15 seconds"});
        loadProjects();
        updateModeUi();

        textModeButton.setOnClickListener(v -> { imageToVideoMode = false; updateModeUi(); });
        imageModeButton.setOnClickListener(v -> { imageToVideoMode = true; updateModeUi(); });
        findViewById(R.id.pickImageButton).setOnClickListener(v -> pickImage());
        findViewById(R.id.pickVideoButton).setOnClickListener(v -> pickVideo());
        generateButton.setOnClickListener(v -> startDemoGeneration());
        findViewById(R.id.clearButton).setOnClickListener(v -> clearForm());
        findViewById(R.id.exportButton).setOnClickListener(v -> showApiNotice());
    }

    private void setupSpinner(Spinner spinner, String[] values) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, values);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(adapter);
    }

    private void updateModeUi() {
        modeLabel.setText(imageToVideoMode ? "IMAGE-TO-VIDEO MODE" : "TEXT-TO-VIDEO MODE");
        imageModeButton.setSelected(imageToVideoMode);
        textModeButton.setSelected(!imageToVideoMode);
        findViewById(R.id.pickImageButton).setVisibility(imageToVideoMode ? View.VISIBLE : View.GONE);
        imageStatus.setVisibility(imageToVideoMode ? View.VISIBLE : View.GONE);
        generateButton.setText(imageToVideoMode ? "✦  Create demo image-to-video" : "✦  Create demo text-to-video");
    }

    private void pickImage() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("image/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_IMAGE);
    }

    private void pickVideo() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.setType("video/*");
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        startActivityForResult(intent, PICK_VIDEO);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();
        if (requestCode == PICK_IMAGE) {
            selectedImage = uri;
            imageStatus.setText("Reference image: " + displayName(uri));
        } else if (requestCode == PICK_VIDEO) {
            selectedVideo = uri;
            videoPreview.setVisibility(View.VISIBLE);
            videoPreview.setVideoURI(uri);
            videoPreview.setOnPreparedListener(mp -> { mp.setLooping(true); videoPreview.start(); });
            previewStatus.setText("Previewing an existing local MP4/video. Demo generation does not create a new MP4.");
        }
    }

    private String displayName(Uri uri) {
        String name = uri.getLastPathSegment();
        try (android.database.Cursor cursor = getContentResolver().query(uri, null, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) {
                int index = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (index >= 0) name = cursor.getString(index);
            }
        } catch (Exception ignored) { }
        return name == null ? "selected" : name;
    }

    private void startDemoGeneration() {
        String prompt = promptInput.getText().toString().trim();
        if (prompt.isEmpty()) {
            promptInput.setError("Write a video prompt first");
            promptInput.requestFocus();
            return;
        }
        if (imageToVideoMode && selectedImage == null) {
            Toast.makeText(this, "Choose a reference image for Image-to-Video mode", Toast.LENGTH_SHORT).show();
            return;
        }
        generateButton.setEnabled(false);
        progressBar.setVisibility(View.VISIBLE);
        progressBar.setProgress(0);
        progressLabel.setVisibility(View.VISIBLE);
        resultText.setVisibility(View.VISIBLE);
        resultText.setText("Preparing your Free Demo project…");
        runProgressStep(0, prompt);
    }

    private void runProgressStep(int step, String prompt) {
        String[] labels = {"Reading prompt…", "Preparing scene settings…", "Building concept preview…", "Almost ready…"};
        if (step < labels.length) {
            progressBar.setProgress((step + 1) * 25);
            progressLabel.setText(labels[step]);
            handler.postDelayed(() -> runProgressStep(step + 1, prompt), 450);
            return;
        }
        String ratio = ratioSpinner.getSelectedItem().toString();
        String style = styleSpinner.getSelectedItem().toString();
        String duration = durationSpinner.getSelectedItem().toString();
        String mode = imageToVideoMode ? "Image-to-Video" : "Text-to-Video";
        String project = String.format(Locale.getDefault(), "%s  |  %s  |  %s  |  %s", mode, style, ratio, duration);
        String entry = project + "\nPrompt: " + prompt + (selectedImage == null ? "" : "\nReference image: attached");
        demoProjects.add(0, entry);
        saveProjects();
        updateGallery();
        progressLabel.setText("Demo concept ready");
        resultText.setText("Your concept preview is ready.\n\n" + entry +
                "\n\nFree Demo Mode does not render or export AI video. A secure backend and external video-generation API are required for a real MP4.");
        generateButton.setEnabled(true);
    }

    private void updateGallery() {
        StringBuilder builder = new StringBuilder();
        for (int i = 0; i < demoProjects.size(); i++) {
            builder.append(i + 1).append(". ").append(demoProjects.get(i)).append("\n\n");
        }
        galleryText.setText(demoProjects.isEmpty() ? "Your saved demo concepts will appear here." : builder.toString());
    }

    private void loadProjects() {
        String saved = getSharedPreferences(PREFS, MODE_PRIVATE).getString("projects", "");
        if (!saved.isEmpty()) {
            String[] items = saved.split("\\n---\\n");
            for (String item : items) if (!item.trim().isEmpty()) demoProjects.add(item);
        }
        updateGallery();
    }

    private void saveProjects() {
        StringBuilder data = new StringBuilder();
        for (String item : demoProjects) {
            if (data.length() > 0) data.append("\n---\n");
            data.append(item);
        }
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString("projects", data.toString()).apply();
    }

    private void showApiNotice() {
        Toast.makeText(this, "Free Demo export is unavailable: connect a secure video API to export MP4.", Toast.LENGTH_LONG).show();
    }

    private void clearForm() {
        handler.removeCallbacksAndMessages(null);
        promptInput.setText("");
        selectedImage = null;
        imageStatus.setText("No image selected");
        resultText.setText("Your concept preview will appear here.");
        progressLabel.setText("");
        progressBar.setProgress(0);
        progressBar.setVisibility(View.GONE);
        progressLabel.setVisibility(View.GONE);
        videoPreview.stopPlayback();
        videoPreview.setVisibility(View.GONE);
        previewStatus.setText("No local video selected");
        generateButton.setEnabled(true);
    }

    @Override
    protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
