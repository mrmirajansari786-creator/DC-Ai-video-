# DC Ai video V2 keeps the default Android optimization rules.
