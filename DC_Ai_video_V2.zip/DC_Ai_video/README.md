# DC Ai video — Android Studio V2

A Java/XML Android Studio concept studio with a premium dark purple cyberpunk interface.

## Included in V2

- Text-to-Video and Image-to-Video modes
- 3D, Realistic, Anime and Cartoon styles
- 9:16, 16:9 and 1:1 formats
- 5, 10 and 15-second duration options
- Free Demo Mode with simulated concept preparation
- Persistent My Projects gallery using local app storage
- Local MP4/video picker and preview using Android VideoView
- Explicit API-required messaging for real generation and MP4 export

## Important limitation

Free Demo Mode does not generate AI video and does not export a new MP4. It creates and stores a concept preview only. Real video generation requires a secure backend, an external video-generation provider, job polling, and authenticated download/export logic. Do not place provider API keys in the Android application.

## Open and build

1. Open this `DC_Ai_video` folder in Android Studio.
2. Allow Gradle sync to download the Android Gradle Plugin and dependencies.
3. Use JDK 17 or newer supported by your Android Studio version.
4. Select an API 35 emulator/device and press Run.

## Project settings

- App name: DC Ai video
- Package: `com.dcai.video`
- Language: Java + XML
- Minimum Android: API 23
- Compile/target SDK: 35
- Version: 2.0
